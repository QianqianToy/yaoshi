CREATE VIEW last.article_collectarticle_view AS
  SELECT
    `c`.`collectID`      AS `collectID`,
    `c`.`title`          AS `title`,
    `a`.`username`       AS `username`,
    `a`.`upNum`          AS `upNum`,
    `a`.`downNum`        AS `downNum`,
    `a`.`flowers`        AS `flowers`,
    `a`.`articleID`      AS `articleID`,
    `c`.`userID`         AS `userID`,
    `a`.`articleBigType` AS `articleBigType`
  FROM `last`.`collectarticles` `c`
    JOIN `last`.`articles` `a`
  WHERE (`c`.`articleID` = `a`.`articleID`);
